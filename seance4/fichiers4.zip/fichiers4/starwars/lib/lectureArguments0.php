<?php
 /* Attention : version très provisoire,
  * la version définitive devra contrôler la validité des arguments
  */ 
 $civilite = $_GET['civilite']; 
 $adhesion = $_GET['adhesion'];
 $nom = $_GET['nom'];
 $prenom = $_GET['prenom'];
 $voie = $_GET['voie'];
 $commune = $_GET['commune'];
 $compl = $_GET['compl'];
 $cp = $_GET['cp'];
 $fig = $_GET['fig'];

?>