<?php
function cercle($cx,$cy,$r){
	return "<circle cx=\"".$cx."\" cy=\"".$cy."\" r=\"".$r."\" />";
}

function carre($cx, $cy, $r) {
	$c = $r*sqrt(2);
	return '<rect x="'.$cx.'" y="'.$cy.'" width="'.$c.'" height="'.$c.'" transform="rotate(0,'.($cx - ($c / 2)).','.($cy - ($c / 2)).')"/>';
}



?>
